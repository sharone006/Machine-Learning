# CreditCard-Fradulent-Analysis-

The dataset includes information about transactions made by credit cards in September 2013 by European cardholders.

The dataset is used to train the Decesion Tree and Support Vector Machines models. 

## Objectives:
        * Perform basic data preprocessing in Python
        * Model a classification task using the Scikit-Learn and Snap ML Python APIs
        * Train Suppport Vector Machine and Decision Tree models using Scikit-Learn and Snap ML
        * Run inference and assess the quality of the trained models
